package com.example.michaelconradmodulethree;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

/**
 * Central SQLite access point for the Inventory Manager app.
 *
 * Two tables are created:
 *   - logins: stores each user's username and a hashed password so the app
 *             can persist accounts across sessions.
 *   - inventory: stores the warehouse inventory grid (item name + quantity)
 *                shown and edited on the InventoryActivity screen.
 *
 * All Create/Read/Update/Delete operations for both tables live here so the
 * Activities stay focused on UI logic instead of raw SQL.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory_manager.db";
    private static final int DATABASE_VERSION = 1;

    // ---------- Logins table ----------
    public static final String TABLE_LOGINS = "logins";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD_HASH = "password_hash";

    private static final String CREATE_TABLE_LOGINS =
            "CREATE TABLE " + TABLE_LOGINS + " (" +
                    COLUMN_USERNAME + " TEXT PRIMARY KEY, " +
                    COLUMN_PASSWORD_HASH + " TEXT NOT NULL" +
                    ");";

    // ---------- Inventory table ----------
    public static final String TABLE_INVENTORY = "inventory";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_ITEM_NAME = "item_name";
    public static final String COLUMN_QUANTITY = "quantity";

    private static final String CREATE_TABLE_INVENTORY =
            "CREATE TABLE " + TABLE_INVENTORY + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_ITEM_NAME + " TEXT NOT NULL, " +
                    COLUMN_QUANTITY + " INTEGER NOT NULL DEFAULT 0" +
                    ");";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_LOGINS);
        db.execSQL(CREATE_TABLE_INVENTORY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Simple upgrade strategy for a class project: drop and recreate.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOGINS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    // =========================================================
    // Login table operations
    // =========================================================

    /** Returns true if an account with this username already exists. */
    public boolean usernameExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_LOGINS,
                new String[]{COLUMN_USERNAME},
                COLUMN_USERNAME + " = ?",
                new String[]{username},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    /**
     * Creates a new login. Returns false (and inserts nothing) if the
     * username is already taken, so callers can tell the user to log in
     * instead of accidentally overwriting an existing account.
     */
    public boolean createLogin(String username, String password) {
        if (usernameExists(username)) {
            return false;
        }
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD_HASH, hashPassword(password));
        long rowId = db.insert(TABLE_LOGINS, null, values);
        return rowId != -1;
    }

    /** Returns true if the username/password combination matches a stored account. */
    public boolean checkLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_LOGINS,
                new String[]{COLUMN_PASSWORD_HASH},
                COLUMN_USERNAME + " = ?",
                new String[]{username},
                null, null, null);

        boolean isValid = false;
        if (cursor.moveToFirst()) {
            String storedHash = cursor.getString(0);
            isValid = storedHash.equals(hashPassword(password));
        }
        cursor.close();
        return isValid;
    }

    /**
     * Hashes the password with SHA-256 before it ever touches the database,
     * so plain-text passwords are never stored on disk.
     */
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(password.getBytes("UTF-8"));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
            // SHA-256/UTF-8 are always available on Android; this is just a
            // defensive fallback so login never crashes the app.
            return password;
        }
    }

    // =========================================================
    // Inventory table operations (Create, Read, Update, Delete)
    // =========================================================

    /** Inserts a new inventory item and returns its generated row id, or -1 on failure. */
    public long addItem(String name, int quantity) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, name);
        values.put(COLUMN_QUANTITY, quantity);
        return db.insert(TABLE_INVENTORY, null, values);
    }

    /** Updates the stored quantity for one item. Returns true if a row was changed. */
    public boolean updateItemQuantity(long id, int quantity) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_QUANTITY, quantity);
        int rowsUpdated = db.update(TABLE_INVENTORY, values,
                COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        return rowsUpdated > 0;
    }

    /** Deletes one inventory item. Returns true if a row was removed. */
    public boolean deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(TABLE_INVENTORY,
                COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        return rowsDeleted > 0;
    }

    /** Reads every inventory row, ordered alphabetically, for display in the grid. */
    public List<InventoryItem> getAllItems() {
        List<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_INVENTORY,
                new String[]{COLUMN_ID, COLUMN_ITEM_NAME, COLUMN_QUANTITY},
                null, null, null, null,
                COLUMN_ITEM_NAME + " ASC");

        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_QUANTITY));
            items.add(new InventoryItem(id, name, quantity));
        }
        cursor.close();
        return items;
    }
}