package com.example.michaelconradmodulethree;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

/**
 * Login screen. Also doubles as the account-creation screen per the
 * assignment instructions: if the entered username does not already exist
 * in the "logins" table, "Create Account" will add it there. Passwords are
 * hashed (see DatabaseHelper) before they are stored.
 */
public class LoginActivity extends AppCompatActivity {

    private TextInputEditText usernameEditText;
    private TextInputEditText passwordEditText;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        databaseHelper = new DatabaseHelper(this);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);

        findViewById(R.id.buttonLogin).setOnClickListener(v -> attemptLogin());
        findViewById(R.id.buttonCreateAccount).setOnClickListener(v -> attemptCreateAccount());
    }

    private boolean credentialsAreValid() {
        String username = usernameEditText.getText() == null ? "" : usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText() == null ? "" : passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter a username and password.", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void attemptLogin() {
        if (!credentialsAreValid()) {
            return;
        }
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Check the username and password against the logins table.
        if (databaseHelper.checkLogin(username, password)) {
            goToInventory();
        } else {
            Toast.makeText(this, "Incorrect username or password.", Toast.LENGTH_SHORT).show();
        }
    }

    private void attemptCreateAccount() {
        if (!credentialsAreValid()) {
            return;
        }
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Insert into the logins table only if that username doesn't already exist.
        boolean created = databaseHelper.createLogin(username, password);
        if (created) {
            Toast.makeText(this, "Account created.", Toast.LENGTH_SHORT).show();
            goToInventory();
        } else {
            Toast.makeText(this, "That username is already taken. Please log in instead.", Toast.LENGTH_SHORT).show();
        }
    }

    private void goToInventory() {
        startActivity(new Intent(this, InventoryActivity.class));
        finish();
    }
}