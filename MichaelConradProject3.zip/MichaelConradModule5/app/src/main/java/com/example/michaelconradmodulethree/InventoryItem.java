package com.example.michaelconradmodulethree;

/**
 * Simple data holder representing one row in the inventory grid.
 * Backed by the "inventory" table in DatabaseHelper; the id field maps to
 * that table's primary key so rows can be updated or deleted precisely.
 */
public class InventoryItem {

    private long id;
    private String name;
    private int quantity;

    public InventoryItem(long id, String name, int quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}