package com.example.michaelconradmodulethree;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.textfield.TextInputEditText;

/**
 * Lets the user opt in to SMS alerts, grants the SEND_SMS runtime
 * permission needed to send them, and saves the phone number that should
 * receive low-stock texts. The saved number and permission choice persist
 * across app restarts via SharedPreferences. If the user denies the
 * permission, the app continues to function normally; it just won't send
 * texts.
 */
public class NotificationsActivity extends AppCompatActivity {

    public static final String PREFS_NAME = "notification_prefs";
    public static final String KEY_PHONE_NUMBER = "phone_number";

    private TextView textPermissionStatus;
    private TextInputEditText phoneNumberEditText;

    private final ActivityResultLauncher<String> requestSmsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    textPermissionStatus.setText(R.string.permission_status_granted);
                    savePhoneNumber();
                    Toast.makeText(this, "SMS notifications enabled.", Toast.LENGTH_SHORT).show();
                } else {
                    textPermissionStatus.setText(R.string.permission_status_denied);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        textPermissionStatus = findViewById(R.id.textPermissionStatus);
        phoneNumberEditText = findViewById(R.id.phoneNumberEditText);

        // Restore any previously saved phone number.
        String savedNumber = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getString(KEY_PHONE_NUMBER, "");
        phoneNumberEditText.setText(savedNumber);

        updatePermissionStatusLabel();

        findViewById(R.id.buttonEnableSms).setOnClickListener(v -> onEnableSmsClicked());
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionStatusLabel();
    }

    private void onEnableSmsClicked() {
        String phoneNumber = phoneNumberEditText.getText() == null
                ? "" : phoneNumberEditText.getText().toString().trim();

        if (TextUtils.isEmpty(phoneNumber)) {
            Toast.makeText(this, "Please enter a phone number first.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean alreadyGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        if (alreadyGranted) {
            savePhoneNumber();
            Toast.makeText(this, "SMS notifications are already enabled.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check for permission before sending; if not granted, trigger the request.
        requestSmsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
    }

    private void savePhoneNumber() {
        String phoneNumber = phoneNumberEditText.getText() == null
                ? "" : phoneNumberEditText.getText().toString().trim();
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_PHONE_NUMBER, phoneNumber)
                .apply();
    }

    private void updatePermissionStatusLabel() {
        boolean granted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
        textPermissionStatus.setText(granted
                ? R.string.permission_status_granted
                : R.string.permission_status_unknown);
    }
}