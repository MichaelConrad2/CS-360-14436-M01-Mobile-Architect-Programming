package com.example.michaelconradmodulethree;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Displays the warehouse inventory as a grid (RecyclerView) backed by the
 * SQLite "inventory" table, and lets the user add items, remove items, and
 * adjust quantities. When an item's quantity is reduced to zero, an SMS
 * alert is sent if the user has granted SMS permission and saved a phone
 * number on the Notifications screen.
 */
public class InventoryActivity extends AppCompatActivity implements InventoryAdapter.OnInventoryActionListener {

    private DatabaseHelper databaseHelper;
    private List<InventoryItem> inventoryItems;
    private InventoryAdapter adapter;
    private RecyclerView recyclerView;
    private TextView textEmptyState;

    private final ActivityResultLauncher<Intent> addItemLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    String name = result.getData().getStringExtra(AddItemActivity.EXTRA_ITEM_NAME);
                    int quantity = result.getData().getIntExtra(AddItemActivity.EXTRA_ITEM_QUANTITY, 0);
                    if (name != null && !name.trim().isEmpty()) {
                        // Create: persist the new row to the database first,
                        // then reflect it in the on-screen grid.
                        long newId = databaseHelper.addItem(name.trim(), quantity);
                        if (newId != -1) {
                            inventoryItems.add(new InventoryItem(newId, name.trim(), quantity));
                            adapter.notifyItemInserted(inventoryItems.size() - 1);
                            updateEmptyState();
                        } else {
                            Toast.makeText(this, "Could not save item to the database.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);

        recyclerView = findViewById(R.id.recyclerViewInventory);
        textEmptyState = findViewById(R.id.textEmptyState);

        // Read: load whatever is already saved in the database so the grid
        // survives app restarts.
        inventoryItems = databaseHelper.getAllItems();

        adapter = new InventoryAdapter(inventoryItems, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        findViewById(R.id.buttonAddItem).setOnClickListener(v ->
                addItemLauncher.launch(new Intent(this, AddItemActivity.class)));

        findViewById(R.id.buttonNotifications).setOnClickListener(v ->
                startActivity(new Intent(this, NotificationsActivity.class)));

        updateEmptyState();
    }

    private void updateEmptyState() {
        boolean isEmpty = inventoryItems.isEmpty();
        textEmptyState.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(isEmpty ? View.GONE : View.VISIBLE);
    }

    @Override
    public void onIncrease(int position) {
        // Update: persist the new quantity immediately so the database never
        // drifts out of sync with what's on screen.
        InventoryItem item = inventoryItems.get(position);
        item.setQuantity(item.getQuantity() + 1);
        databaseHelper.updateItemQuantity(item.getId(), item.getQuantity());
        adapter.notifyItemChanged(position);
    }

    @Override
    public void onDecrease(int position) {
        InventoryItem item = inventoryItems.get(position);
        if (item.getQuantity() <= 0) {
            return;
        }
        item.setQuantity(item.getQuantity() - 1);
        databaseHelper.updateItemQuantity(item.getId(), item.getQuantity());
        adapter.notifyItemChanged(position);

        if (item.getQuantity() == 0) {
            notifyItemOutOfStock(item);
        }
    }

    @Override
    public void onDelete(int position) {
        // Delete: remove from the database first, then from the visible list.
        InventoryItem item = inventoryItems.get(position);
        databaseHelper.deleteItem(item.getId());
        inventoryItems.remove(position);
        adapter.notifyItemRemoved(position);
        updateEmptyState();
    }

    /**
     * Sends an SMS alert when an item's quantity reaches zero, provided the
     * user has granted SEND_SMS permission and saved a phone number. If
     * either is missing, the app continues to function normally; it simply
     * skips the text message.
     */
    private void notifyItemOutOfStock(InventoryItem item) {
        boolean hasPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        if (!hasPermission) {
            // No permission: fail silently for the user, app keeps working.
            return;
        }

        SharedPreferences prefs = getSharedPreferences(NotificationsActivity.PREFS_NAME, Context.MODE_PRIVATE);
        String phoneNumber = prefs.getString(NotificationsActivity.KEY_PHONE_NUMBER, null);

        if (TextUtils.isEmpty(phoneNumber)) {
            Toast.makeText(this,
                    item.getName() + " is out of stock. Add a phone number on the Notifications screen to receive text alerts.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            String message = item.getName() + " is out of stock. Please reorder.";
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Low-stock text alert sent for " + item.getName() + ".", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            // Sending can fail on devices/emulators without an active SIM;
            // the rest of the app should keep working regardless.
            Toast.makeText(this, "Could not send SMS alert: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}