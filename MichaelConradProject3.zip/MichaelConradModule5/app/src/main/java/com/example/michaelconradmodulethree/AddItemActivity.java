package com.example.michaelconradmodulethree;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

/**
 * Screen for adding a new item (name + starting quantity) to the inventory.
 * Returns the entered values to InventoryActivity via setResult().
 *
 * NOTE: This is the Project Two UI-only milestone. Persisting the new row
 * to the SQLite inventory table happens in Project Three.
 */
public class AddItemActivity extends AppCompatActivity {

    public static final String EXTRA_ITEM_NAME = "extra_item_name";
    public static final String EXTRA_ITEM_QUANTITY = "extra_item_quantity";

    private TextInputEditText itemNameEditText;
    private TextInputEditText itemQuantityEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        itemNameEditText = findViewById(R.id.itemNameEditText);
        itemQuantityEditText = findViewById(R.id.itemQuantityEditText);

        findViewById(R.id.buttonSaveItem).setOnClickListener(v -> saveItem());
        findViewById(R.id.buttonCancelAddItem).setOnClickListener(v -> finish());
    }

    private void saveItem() {
        String name = itemNameEditText.getText() == null ? "" : itemNameEditText.getText().toString().trim();
        String quantityText = itemQuantityEditText.getText() == null ? "" : itemQuantityEditText.getText().toString().trim();

        if (name.isEmpty()) {
            Toast.makeText(this, "Please enter an item name.", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;
        try {
            quantity = quantityText.isEmpty() ? 0 : Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid whole number for quantity.", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent resultIntent = new Intent();
        resultIntent.putExtra(EXTRA_ITEM_NAME, name);
        resultIntent.putExtra(EXTRA_ITEM_QUANTITY, quantity);
        setResult(RESULT_OK, resultIntent);
        finish();
    }
}